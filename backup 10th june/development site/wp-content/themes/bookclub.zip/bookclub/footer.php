    <footer class="footer">
      <div class="container">
      	<div class="col-md-6">
      		<h4>Categories</h4>
	        <ul class="list-inline">
                <li>
                    <a href="#">All</a>
                </li>
                <li class="footer-menu-divider">⋅</li>
                <li>
                    <a href="#about">Action</a>
                </li>
                <li class="footer-menu-divider">⋅</li>
                <li>
                    <a href="#services">Adventure</a>
                </li>
                <li class="footer-menu-divider">⋅</li>
                <li>
                    <a href="#contact">Comedy</a>
                </li>
            </ul>
        </div><!-- /.col -->
        <div class="col-md-6">
	        <p class="pull-right">&copy Rosendale Primary School 2015</p>
        </div><!-- /.col -->
      </div><!-- /.container -->
    </footer>


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- jQuery -->
    <!-- <script src="js/jquery-1.11.3.min.js"></script> -->
    <!-- Bootstrap Core JavaScript -->
    <!-- <script src="js/bootstrap.min.js"></script> -->
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <!-- <script src="js/ie10-viewport-bug-workaround.js"></script> -->

    <?php wp_footer(); ?>
  </body>
</html>